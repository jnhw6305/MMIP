# MMIP HW7 實驗報告：LLM Prompt Engineering 與模型量化

## 實驗目標

部署開源模型 `Qwen/Qwen2.5-1.5B-Instruct`，以 20 題自建 Instruction Benchmark 比較提示工程與 NF4 4-bit 量化對正確率、延遲及 GPU 記憶體的影響。

## 環境與方法

- GPU：Tesla T4
- 預設精度：BF16；量化精度：NF4 4-bit（計算精度 torch.bfloat16）
- 解碼：greedy decoding，do_sample=False
- 設計：2（BF16/NF4）× 2（Default/Enhanced prompt），每格 20 題
- 主要指標：deterministic grader accuracy
- 記憶體：每題 CUDA peak allocated，對 20 題取平均

## 結果

| precision   | prompt_type   |   accuracy_pct |   avg_latency_sec |   avg_peak_allocated_gib |   avg_incremental_peak_gib |
|:------------|:--------------|---------------:|------------------:|-------------------------:|---------------------------:|
| BF16        | default       |             70 |             0.364 |                    2.889 |                      0.005 |
| BF16        | enhanced      |             80 |             0.338 |                    2.896 |                      0.012 |
| NF4         | default       |             45 |             0.464 |                    3.99  |                      0.031 |
| NF4         | enhanced      |             75 |             0.429 |                    3.996 |                      0.037 |

- BF16 下 Prompt Engineering 改變：+10.0 個百分點。
- NF4 下 Prompt Engineering 改變：+30.0 個百分點。
- Default prompt 下 NF4 相對 BF16 的正確率差：-25.0 個百分點。
- NF4 相對 BF16 的平均 GPU 完整峰值降低：-38.1%。

![四組實驗比較](comparison.png)

## 結論

本實驗以配對設計控制題目與解碼設定，將 Prompt 與量化兩項因素分離。Enhanced prompt 是否有效應以以上實測百分點判定；NF4 是否值得採用則需同時考慮正確率差、記憶體節省與延遲。由於樣本僅 20 題，結果適合描述此自建 benchmark，不宜直接外推至所有任務。

## 可重現性與限制

題目、參考答案、grader 與原始逐題輸出均隨附。生成是 deterministic，但不同 GPU、CUDA、Transformers 或 bitsandbytes 版本仍可能造成細微差異。自動 grader 對語意等價表達較嚴格；未使用商用 LLM judge，可避免 judge 偏差與 API 成本，但犧牲開放式回答的語意敏感度。
