# 作業 C：DPO 微調 LLM/VLM 實驗報告

## 基礎：LLM DPO
- 模型：Qwen/Qwen2.5-0.5B-Instruct，NF4 QLoRA，DPO 120 組。
- 優化面向：正確且簡潔的繁體中文回答。
- target exact accuracy：0.0% → 10.0%（+10.0 個百分點）。
- 無關的 100 題通用 benchmark：53.0% → 60.0%（+7.0 個百分點）。

## 進階：VLM DPO
- 模型：HuggingFaceTB/SmolVLM-500M-Instruct，LoRA DPO；完整 120 組影像偏好資料以 seed=42 洗牌後分成 4 批、每批 30 組，依序更新同一 adapter。
- 優化面向：描述可見形狀時避免提及不存在物件。
- 原圖 hallucination rate：0.0% → 0.0%（+0.0 個百分點）。
- 微調後另測 original、亮度 0.35、亮度 1.70、Gaussian blur r=4、JPEG quality=15；完整數字見 `vlm_summary.csv`。

![比較圖](dpo_comparison.png)

## 結論與限制
以上結論以未進入訓練的測試集計算。LLM 通用能力以 100 題 exact match 衡量；VLM 幻覺以已知顏色—形狀詞彙集合量化。為符合 Colab T4 系統記憶體限制，VLM 採用 4×30 sequential chunk DPO：各階段沿用同一 LoRA adapter，但 Trainer、optimizer 與 scheduler 會重建，因此不完全等同於單一 120 筆標準 DPO epoch。
