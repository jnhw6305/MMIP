# 作業 B：視覺多模態大模型比較

## 方法
本實驗部署兩個 Apache-2.0 開源 VLM：Qwen/Qwen2.5-VL-3B-Instruct 與 HuggingFaceTB/SmolVLM2-2.2B-Instruct。使用 20 道自建合成影像 benchmark，兩模型的影像、問題、system prompt、greedy decoding 與 max_new_tokens 完全相同。主要量化指標為 exact-match accuracy。

## 結果
| model                                |   accuracy |   avg_latency_sec |   avg_peak_gpu_gib |   accuracy_pct |   model_footprint_gib |
|:-------------------------------------|-----------:|------------------:|-------------------:|---------------:|----------------------:|
| HuggingFaceTB/SmolVLM2-2.2B-Instruct |        0.9 |             1.158 |              4.607 |             90 |                 4.185 |
| Qwen/Qwen2.5-VL-3B-Instruct          |        1   |             0.772 |              7.069 |            100 |                 6.994 |

本 benchmark 正確率較高者為 **Qwen/Qwen2.5-VL-3B-Instruct**。分類別結果見 `category_summary.csv`；逐題原始輸出見 `vlm_results.csv`，因此失敗案例可稽核。

![比較圖](vlm_comparison.png)

## 限制
合成影像能精確控制答案，但不代表自然影像的全部難度；exact match 對同義詞較嚴格。結論只適用於本 20 題 benchmark，不應外推為模型整體排名。
